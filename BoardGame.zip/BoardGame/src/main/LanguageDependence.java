package main;

import java.util.List;

public class LanguageDependence {

	
}